<?php 
// silens is golden.