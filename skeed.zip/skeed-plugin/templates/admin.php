<h1>New Employee</h1>

<?php
global $wp;
?>
    <form method="POST" action="<?php home_url( $wp->request ) ?>">
        
    <label for="fname">First name:</label><br>
    <input type="text" id="fname" name="fname" value="Georgi"><br>
    <label for="lname">Last name:</label><br>
    <input type="text" id="lname" name="lname" value="Dimov"><br>
    <label for="phone">Last name:</label><br>
    <input type="text" id="phone" name="phone" value="phone"><br>
    <label for="position">Last name:</label><br>
    <input type="text" id="position" name="position" value="position"><br><br>
    <input type="submit" value="Add New Employee">
    
    </form> 

<hr>
    <?php 
function new_employee( string $fName, string $lName, string $phone, string $position, ) {
    global $wpdb;
    
    $employees = $wpdb->get_results( "SELECT * FROM wp_employees" );
    
    // echo "<pre>";
    // echo print_r($employees);
    // echo "</pre>";
    ?>

    
    <h2>Employees</h2>
    
    <table>
        <tr>
            <th style="width: 10px;">Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Phone</th>
            <th>Position</th>
        </tr>
            <?php

    foreach ( $employees as $employee ) {
        
        ?>

    <tr>
        <td><?php echo $employee->id ?></td>
        <td><?php echo $employee->first_name ?></td>
        <td><?php echo $employee->last_name ?></td>
        <td><?php echo $employee->phone ?></td>
        <td><?php echo $employee->position ?></td>
    </tr>
    <?php

    }
    ?>     
    </table>
    
    <?php        
    $table_name = $wpdb->prefix . 'employees';
    
    $wpdb->insert( 
        $table_name, 
        array( 
            'first_name' => $fName, 
            'last_name' => $lName, 
            'phone' => $phone, 
            'position' => $position,
        ) 
    );

   
}

if ( isset( $_POST['fname'] ) && isset( $_POST['lname'] )) {
    
    
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $phone = $_POST['phone'];
    $position = $_POST['position'];
    
    register_activation_hook( __FILE__, [new_employee( $firstName, $lastName, $phone, $position )] );
}