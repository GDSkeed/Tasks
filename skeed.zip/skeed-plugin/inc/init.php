<?php 
/**
 * @package SkeedPlugin
 */

namespace Inc;

use Inc\Pages\Admin;
use Inc\Base\Enqueue;
use Inc\Base\SettingsLinks;

 final class Init
 {
    
    /**
     * Store all the classes inside an array
     *
     * @return array Full list of classes
     */
    public static function get_services() {
        return [
            Admin::class,
            Enqueue::class,
            SettingsLinks::class,
        ];
    }
    
    /**
     * Loop through the classes, initialize them, and call the register() if it exists
     *
     * @return void
     */
    public static function register_services() {
        foreach ( self::get_services() as $class ) {
            $service = self::instantiate( $class );
            if ( method_exists( $service, 'register' ) ) {
                $service->register();
            }
        }
    }
    
    /**
     * Initialize the class
     *
     * @param  class $class class from the services array
     * @return class instance new instance of the class
     */
    private static function instantiate( $class ) {
        $service = new $class;
        return $service;
    }
 }



















 
// use Inc\Base\Activate;
// use Inc\Base\Deactivate;
// use Inc\Pages\Admin;

// class SkeedPlugin 
// {

//     private $name;

//     public function __construct() {
//         $this->setName(plugin_basename( __FILE__ ));        
//     }

//     public function register() {
//         add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );

//         add_action( 'admin_menu', [ $this, 'add_admin_pages' ] );        

//         add_filter( "plugin_action_links_" . $this->getName(), [ $this, 'settings_link' ] );
//     }

//     public function settings_link( $links ) {
//         $settings_link = '<a href="admin.php?page=skeed_plugin">Settings</a>';
//         array_push( $links, $settings_link );
//         return $links;
//     }

//     public function add_admin_pages() {
//         add_menu_page( 'Skeed Plugin', 'Skeed', 'manage_options', 'skeed_plugin', [ $this, 'admin_index' ], 'dashicons-businessperson', 110 );
//     }

//     public function admin_index() {
//         require_once plugin_dir_path( __FILE__ ) . 'templates/admin.php';
//     }

//     protected function create_post_type() {
//         add_action( 'init', [ $this, 'custom_post_type' ] );
//     }

//     // function uninstall() {
//     //     // delete CPT ( Custom Post Type )
//     //     // Delete all the plugin data from the DB
//     // }

//     function custom_post_type() {

//         $labels = array(
//             'name'                  => _x( 'Employees', 'Post type general name', 'textdomain' ),
//             'singular_name'         => _x( 'Employee', 'Post type singular name', 'textdomain' ),
//             'menu_name'             => _x( 'Employees', 'Admin Menu text', 'textdomain' ),
//             'name_admin_bar'        => _x( 'Book', 'Add New on Toolbar', 'textdomain' ),
//             'add_new'               => __( 'Add New', 'textdomain' ),
//             'add_new_item'          => __( 'Add New Employee', 'textdomain' ),
//             'new_item'              => __( 'New Employee', 'textdomain' ),
//             'edit_item'             => __( 'Edit Employee', 'textdomain' ),
//             'view_item'             => __( 'View Employee', 'textdomain' ),
//             'all_items'             => __( 'All Employees', 'textdomain' ),
//             'search_items'          => __( 'Search Employee', 'textdomain' ),
//             'parent_item_colon'     => __( 'Parent Employees:', 'textdomain' ),
//             'not_found'             => __( 'No employees found.', 'textdomain' ),
//             'not_found_in_trash'    => __( 'No employees found in Trash.', 'textdomain' ),
//             'featured_image'        => _x( 'Employee Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
//             'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
//             'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
//             'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
//             'archives'              => _x( 'Employee archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
//             'insert_into_item'      => _x( 'Insert into employee', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
//             'uploaded_to_this_item' => _x( 'Uploaded to this employee', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
//             'filter_items_list'     => _x( 'Filter employees list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
//             'items_list_navigation' => _x( 'Employees list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
//             'items_list'            => _x( 'Employees list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
//         );

//         $args = array(
//             'labels'             => $labels,
//             'public'             => true,
//             'publicly_queryable' => true,
//             'show_ui'            => true,
//             'show_in_menu'       => true,
//             'query_var'          => true,
//             'rewrite'            => array( 'slug' => 'employee' ),
//             'capability_type'    => 'post',
//             'has_archive'        => true,
//             'hierarchical'       => false,
//             'menu_position'      => null,
//             'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
//         );

//         register_post_type( 'employee', $args );
//     }

//     function enqueue() {
//         // enqueue scripts
//         wp_enqueue_style( 'pluginstyle', plugins_url( '/assets/style.css', __FILE__ ) );
//         wp_enqueue_style( 'pluginscript', plugins_url( '/assets/script.js', __FILE__ ) );
//     }

//     function activate() {
//         // require_once plugin_dir_path( __FILE__ ) . 'inc/Base/Activate.php';
//         Activate::activate();
//     }

//     function deactivate() {
//         // require_once plugin_dir_path( __FILE__ ) . 'inc/Base/Deactivate.php';
//         Deactivate::deactivate();
//     }

//     public function getName(): string
//     {
//         return $this->name;
//     }

//     public function setName(string $name): void
//     {
//         $this->name = $name;
//     }
// }

// if ( class_exists( 'SkeedPlugin' ) ) {
//     $skeedPlugin = new SkeedPlugin();
//     $skeedPlugin->register();
// }

// // Activation
// register_activation_hook( __FILE__, [ $skeedPlugin, 'activate' ] );

// // Deactivation
// register_activation_hook( __FILE__, [ $skeedPlugin, 'deactivate' ] );

// // Uninstall
// // register_uninstall_hook( __FILE__, array( $skeedPlugin, 'uninstall' ) );