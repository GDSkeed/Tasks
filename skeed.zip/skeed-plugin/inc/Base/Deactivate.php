<?php 
/**
 * @package GDSkeedPlugin
 */

namespace Inc\Base;
 
 /**
  * Deactivate
  */
 class Deactivate
 {    
    /**
     * deactivate
     *
     * @return void
     */
    public static function deactivate() 
    {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
 }