<?php 
/**
 * @package SkeedPlugin
 */

namespace Inc\Base;

/**
 * 
 */
class Enqueue
{
    public function register() 
    {
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
    }

    public function enqueue() 
    {
        // enqueue scripts
        wp_enqueue_style( 'pluginstyle', PLUGIN_URL . 'assets/style.css' );
        wp_enqueue_style( 'pluginscript', PLUGIN_URL . 'assets/script.js' );
    }
}