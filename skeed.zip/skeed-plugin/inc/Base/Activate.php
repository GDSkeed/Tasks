<?php 
/**
 * @package SkeedPlugin
 */

namespace Inc\Base;
 
 /**
  * Activate
  */
 class Activate
 {    
    public static function activate() 
    {        
        // Flush rewrite rules
        flush_rewrite_rules();        
    }
    
 }