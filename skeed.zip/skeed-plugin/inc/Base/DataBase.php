<?php 
/**
 * @package SkeedPlugin
 */

namespace Inc\Base;
 
 /**
  * 
  */
 class DataBase
 {    
    public static function activate() 
    {        
        // Flush rewrite rules
        flush_rewrite_rules();        
    }
    
    public static function create_db_employees() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
    
        $table_name = $wpdb->prefix . 'employees';
    
        $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . " (
            id int(11) NOT NULL AUTO_INCREMENT,
            first_name tinytext NOT NULL,
            last_name tinytext NOT NULL,
            phone int(13) NULL,
            position text NOT NULL,
            ip_address varchar(15),
            PRIMARY KEY  (id),
            KEY ip_address (ip_address)
            ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
 }