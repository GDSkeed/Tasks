<?php 
/**
 * @package SkeedPlugin
 */

namespace Inc\Pages;

/**
 * add_admin_pages
 */
class Admin
{
    public function register() 
    {
        add_action( 'admin_menu', array( $this, 'addAdminPages' ) );
    }

    public function addAdminPages()
    {
        add_menu_page( 'Skeed Plugin', 'Skeed', 'manage_options', 'skeed_plugin', array( $this, 'adminIndex' ), 'dashicons-businessperson', 110 );
    }

    public function adminIndex()
    {
        require_once PLUGIN_PATH . 'templates/admin.php';       
    }    
}